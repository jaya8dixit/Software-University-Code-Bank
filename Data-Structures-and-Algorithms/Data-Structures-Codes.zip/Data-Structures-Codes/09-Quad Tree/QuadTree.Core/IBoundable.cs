﻿public interface IBoundable
{
    Rectangle Bounds { get; set; }
}
